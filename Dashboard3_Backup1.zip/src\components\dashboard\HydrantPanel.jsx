import { useMemo } from 'react';
import { Droplets } from 'lucide-react';

const CX = 75, CY = 72;
const START = 135, SWEEP = 270;

function ptc(cx, cy, r, deg) {
  const rad = (deg * Math.PI) / 180;
  return [+(cx + r * Math.cos(rad)).toFixed(2), +(cy + r * Math.sin(rad)).toFixed(2)];
}
function arcD(r, startDeg, endDeg, cx = CX, cy = CY) {
  const [sx, sy] = ptc(cx, cy, r, startDeg);
  const [ex, ey] = ptc(cx, cy, r, endDeg);
  const span  = ((endDeg - startDeg) + 360) % 360;
  const large = span > 180 ? 1 : 0;
  return `M ${sx} ${sy} A ${r} ${r} 0 ${large} 1 ${ex} ${ey}`;
}

const VALVE_STATUS = {
  OPEN:   { color: '#2a9d8f', label: 'TERBUKA',  bg: 'rgba(42,157,143,0.10)',  border: 'rgba(42,157,143,0.3)'  },
  CLOSED: { color: '#c24b4b', label: 'TERTUTUP', bg: 'rgba(194,75,75,0.08)',   border: 'rgba(194,75,75,0.3)'   },
};

export default function HydrantPanel({ pressure = 0, valve_status = 'CLOSED', maxPressure = 12 }) {
  const vs  = VALVE_STATUS[valve_status] || VALVE_STATUS.CLOSED;
  const pct = Math.max(0, Math.min(1, pressure / maxPressure));
  const pressColor = pressure < 2 ? '#c24b4b' : pressure < 4 ? '#c9a227' : '#2a9d8f';

  const needleAngle = START + pct * SWEEP;
  const [tx, ty]    = ptc(CX, CY, 42, needleAngle);
  const [b1x, b1y]  = ptc(CX, CY, 6,  needleAngle + 90);
  const [b2x, b2y]  = ptc(CX, CY, 6,  needleAngle - 90);
  const [rlx, rly]  = ptc(CX, CY, 11, needleAngle + 180);

  const { major, minor } = useMemo(() => {
    const major = Array.from({ length: 7 }, (_, i) => {
      const f   = i / 6;
      const deg = START + f * SWEEP;
      const [ox, oy] = ptc(CX, CY, 58, deg);
      const [ix, iy] = ptc(CX, CY, 50, deg);
      const [lx, ly] = ptc(CX, CY, 42, deg);
      const lv = (maxPressure * f).toFixed(0);
      return { ox, oy, ix, iy, lx, ly, lv };
    });
    const minor = [];
    for (let i = 0; i < 6; i++) {
      for (let j = 1; j <= 3; j++) {
        const f   = (i + j / 4) / 6;
        const deg = START + f * SWEEP;
        const [ox, oy] = ptc(CX, CY, 58, deg);
        const [ix, iy] = ptc(CX, CY, 53, deg);
        minor.push({ ox, oy, ix, iy });
      }
    }
    return { major, minor };
  }, [maxPressure]);

  const zones = [
    { s: 0,    e: 0.17, color: '#c24b4b' }, // < 2 Bar danger
    { s: 0.17, e: 0.33, color: '#c9a227' }, // 2–4 Bar warning
    { s: 0.33, e: 1.0,  color: '#2a9d8f' }, // > 4 Bar normal
  ];

  return (
    <div className="card">
      <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
        🚒 Smart Hydrant Monitoring
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 32 }}>

        {/* Left: Hydrant Icon + Valve */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, flexShrink: 0 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Droplets size={28} color="#3b82f6" style={{ filter: 'drop-shadow(0 0 8px rgba(59,130,246,0.6))' }} />
          </div>
          <div style={{
            padding: '5px 14px', borderRadius: 999, fontSize: 11, fontWeight: 800,
            color: vs.color, background: vs.bg, border: `1px solid ${vs.border}`,
            letterSpacing: '0.05em', whiteSpace: 'nowrap',
          }}>
            {vs.label}
          </div>
          <div style={{ fontSize: 9, color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Status Katup
          </div>
        </div>

        {/* Right: Speedometer Gauge */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <div style={{ fontSize: 9, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2, fontWeight: 700 }}>
            Tekanan Hydrant
          </div>
          <svg width={150} height={138} viewBox="0 0 150 138" style={{ overflow: 'visible' }}>
            <defs>
              <filter id="hy-glow" x="-40%" y="-40%" width="180%" height="180%">
                <feGaussianBlur stdDeviation="3" result="b"/>
                <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              <filter id="hy-nglow" x="-80%" y="-80%" width="260%" height="260%">
                <feGaussianBlur stdDeviation="2" result="b"/>
                <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              <radialGradient id="hy-hub" cx="40%" cy="35%" r="60%">
                <stop offset="0%" stopColor="#243f68"/>
                <stop offset="100%" stopColor="#060d1c"/>
              </radialGradient>
            </defs>

            {/* Zone ring */}
            {zones.map((z, i) => {
              const s = START + z.s * SWEEP;
              const e = START + z.e * SWEEP;
              return (
                <path key={i} d={arcD(65, s, e)} fill="none"
                  stroke={z.color} strokeWidth="3" opacity="0.45" strokeLinecap="round"
                />
              );
            })}

            {/* Background track */}
            <path d={arcD(55, START, START + SWEEP)} fill="none"
              stroke="#0f1f38" strokeWidth="11" strokeLinecap="round"
            />
            <path d={arcD(55, START, START + SWEEP)} fill="none"
              stroke="#1a3558" strokeWidth="9" strokeLinecap="round" opacity="0.6"
            />

            {/* Value arc */}
            {pct > 0.01 && (
              <path d={arcD(55, START, START + pct * SWEEP)} fill="none"
                stroke={pressColor} strokeWidth="9" strokeLinecap="round"
                filter="url(#hy-glow)"
                style={{ transition: 'd 0.6s ease' }}
              />
            )}

            {/* Minor ticks */}
            {minor.map((t, i) => (
              <line key={i} x1={t.ox} y1={t.oy} x2={t.ix} y2={t.iy}
                stroke="#1e3a5f" strokeWidth="1" strokeLinecap="round"
              />
            ))}

            {/* Major ticks + labels */}
            {major.map((t, i) => {
              const f = i / 6;
              const tc = f < 0.17 ? '#ef4444' : f < 0.33 ? '#f59e0b' : '#10b981';
              return (
                <g key={i}>
                  <line x1={t.ox} y1={t.oy} x2={t.ix} y2={t.iy}
                    stroke={tc} strokeWidth="2" strokeLinecap="round" opacity="0.8"
                  />
                  <text x={t.lx} y={t.ly} textAnchor="middle" dominantBaseline="middle"
                    fill="#3d5068" fontSize="7" fontFamily="'JetBrains Mono', monospace"
                  >
                    {t.lv}
                  </text>
                </g>
              );
            })}

            {/* Needle shadow */}
            <polygon
              points={`${tx},${ty} ${b1x},${b1y} ${rlx},${rly} ${b2x},${b2y}`}
              fill="rgba(0,0,0,0.35)" transform="translate(1.5,2.5)"
            />

            {/* Needle */}
            <polygon
              points={`${tx},${ty} ${b1x},${b1y} ${rlx},${rly} ${b2x},${b2y}`}
              fill={pressColor}
              filter="url(#hy-nglow)"
              style={{ transition: 'all 0.6s cubic-bezier(0.34,1.56,0.64,1)' }}
            />
            <circle cx={tx} cy={ty} r={1.8} fill="white" opacity="0.9" />

            {/* Hub */}
            <circle cx={CX} cy={CY} r={10} fill="url(#hy-hub)" stroke="#243f68" strokeWidth="1.2"/>
            <circle cx={CX} cy={CY} r={6}  fill="#0a1628" stroke="#1a3558" strokeWidth="0.8"/>
            <circle cx={CX} cy={CY} r={3.5} fill={pressColor}
              style={{ filter: `drop-shadow(0 0 4px ${pressColor})` }}
            />
            <circle cx={CX} cy={CY} r={2} fill="white" opacity="0.85"/>

            {/* Value */}
            <text x={CX} y={CY + 22} textAnchor="middle"
              fill="#e2e8f0" fontSize="18" fontWeight="800"
              fontFamily="'JetBrains Mono', monospace"
              style={{ filter: `drop-shadow(0 0 6px ${pressColor}80)` }}
            >
              {pressure.toFixed(1)}
            </text>
            <text x={CX} y={CY + 34} textAnchor="middle" fill="#64748b" fontSize="9" fontWeight="600">
              Bar
            </text>

            {/* Min / Max */}
            <text x={12}  y={130} textAnchor="middle" fill="#2d4060" fontSize="7">0</text>
            <text x={138} y={130} textAnchor="middle" fill="#2d4060" fontSize="7">{maxPressure}</text>

            {/* Status */}
            <text x={CX} y={133} textAnchor="middle" fill={pressColor} fontSize="8" fontWeight="700">
              ● {pressure < 2 ? 'BAHAYA' : pressure < 4 ? 'WASPADA' : 'NORMAL'}
            </text>
          </svg>
        </div>
      </div>
    </div>
  );
}
