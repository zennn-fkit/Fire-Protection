import { Zap, Activity, Radio } from 'lucide-react';
import { ZONE_DEFAULT, ZONE_VOLTAGE, ZONE_FREQUENCY } from '../utils/gaugeZones';
import { useSensor } from '../context/SensorContext';
import GaugeCard from '../components/dashboard/GaugeCard';
import EnergyChart      from '../components/dashboard/EnergyChart';
import SensorStatusCard from '../components/dashboard/SensorStatusCard';
import HydrantPanel     from '../components/dashboard/HydrantPanel';
import WaterTankPanel   from '../components/dashboard/WaterTankPanel';
import EnvPanel         from '../components/dashboard/EnvPanel';
import Header           from '../components/layout/Header';

function StatPill({ label, value, unit, color, Icon }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '6px 14px',
      background: `${color}12`, border: `1px solid ${color}30`, borderRadius: 999,
      flex: 1, minWidth: 150
    }}>
      <Icon size={13} color={color} />
      <span style={{ fontSize: 12, fontWeight: 700, color, fontFamily: "'JetBrains Mono', monospace" }}>
        {value} {unit}
      </span>
      <span style={{ fontSize: 10, color: '#64748b' }}>{label}</span>
    </div>
  );
}

export default function Dashboard() {
  const { state } = useSensor();
  const { node1, node2, node3, node4, detectors, water_level, energyHistory } = state;

  const anyDanger  = Object.values(detectors).some(v => v === 'DANGER');
  const anyWarning = Object.values(detectors).some(v => v === 'WARNING');

  return (
    <div className="page-gradient">
      <Header title="Dashboard Monitoring" />

      {/* Critical Alert Banner */}
      {anyDanger && (
        <div style={{
          margin: '16px 28px 0', padding: '12px 20px', borderRadius: 12,
          background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.5)',
          display: 'flex', alignItems: 'center', gap: 10,
          animation: 'danger-pulse 2s ease-in-out infinite',
        }}>
          <span style={{ fontSize: 20 }}>🚨</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#ef4444' }}>
            BAHAYA KEBAKARAN TERDETEKSI! Harap segera ambil tindakan!
          </span>
        </div>
      )}

      <div style={{ padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>

        {/* ── Row 0: Quick Stats ───────────────────────────────── */}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <StatPill label="Tegangan"   value={node1.voltage.toFixed(1)}     unit="V"   color="#4a7fc1" Icon={Zap}      />
          <StatPill label="Arus"       value={node1.current_amp.toFixed(1)} unit="A"   color="#c87941" Icon={Activity} />
          <StatPill label="Frekuensi"  value={node1.frequency.toFixed(2)}   unit="Hz"  color="#2a9d8f" Icon={Radio}    />
          <StatPill label="Daya"       value={node1.power_kw.toFixed(2)}    unit="kW"  color="#7c5cba" Icon={Zap}      />
        </div>

        {/* ── Row 1: Power Gauges + Hydrant ───────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          <GaugeCard
            label="Tegangan" value={node1.voltage} min={180} max={260}
            unit="Volt AC" threshKey="voltage" decimals={1}
            zones={ZONE_VOLTAGE}
          />
          <GaugeCard
            label="Arus" value={node1.current_amp} min={0} max={180}
            unit="Ampere" threshKey="current_amp" decimals={1}
            zones={ZONE_DEFAULT}
          />
          <GaugeCard
            label="Frekuensi" value={node1.frequency} min={45} max={55}
            unit="Hz" threshKey="frequency" decimals={2}
            zones={ZONE_FREQUENCY}
          />
          <HydrantPanel
            pressure={node4.pressure}
            valve_status={node4.valve_status}
            maxPressure={12}
          />
        </div>

        {/* ── Row 2: Charts ───────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <EnergyChart data={energyHistory} title="Monitoring Realtime 1" initialMetric="kw" />
          <EnergyChart data={energyHistory} title="Monitoring Realtime 2" initialMetric="voltage" />
        </div>

        {/* ── Row 3: Env Panels + Water + Detectors ───────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          <div style={{ gridColumn: 'span 2', display: 'flex' }}>
            <EnvPanel 
              title="Monitoring Sensor" 
              nodes={[
                { label: 'Panel Environment (Node 2)', data: node2 },
                { label: 'Lingkungan (Node 3)', data: node3 }
              ]}
              style={{ flex: 1 }}
            />
          </div>
          <WaterTankPanel level={water_level} />
          <SensorStatusCard detectors={detectors} />
        </div>

      </div>
    </div>
  );
}
