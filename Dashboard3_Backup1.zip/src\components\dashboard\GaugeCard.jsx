import { useMemo } from 'react';
import { getStatus, STATUS_COLORS } from '../../utils/thresholds';
import { ZONE_DEFAULT, ZONE_VOLTAGE } from '../../utils/gaugeZones';


const CX = 100, CY = 98;
const START = 135, SWEEP = 270;

function ptc(cx, cy, r, deg) {
  const rad = (deg * Math.PI) / 180;
  return [+(cx + r * Math.cos(rad)).toFixed(2), +(cy + r * Math.sin(rad)).toFixed(2)];
}

function arcD(r, startDeg, endDeg) {
  const [sx, sy] = ptc(CX, CY, r, startDeg);
  const [ex, ey] = ptc(CX, CY, r, endDeg);
  const span = ((endDeg - startDeg) + 360) % 360;
  const large = span > 180 ? 1 : 0;
  return `M ${sx} ${sy} A ${r} ${r} 0 ${large} 1 ${ex} ${ey}`;
}

export default function GaugeCard({
  label, value, min = 0, max = 100, unit,
  threshKey, decimals = 1,
  zones = ZONE_DEFAULT,
}) {
  const status = threshKey ? getStatus(threshKey, value) : 'normal';
  const sc  = STATUS_COLORS[status];
  const pct = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const id  = `sp-${(label + unit).replace(/[^a-zA-Z0-9]/g, '')}`;

  const needleAngle  = START + pct * SWEEP;
  const valueEndDeg  = START + pct * SWEEP;

  // Needle shape
  const [tx, ty]  = ptc(CX, CY, 58, needleAngle);
  const [b1x, b1y] = ptc(CX, CY, 9, needleAngle + 90);
  const [b2x, b2y] = ptc(CX, CY, 9, needleAngle - 90);
  const [rlx, rly] = ptc(CX, CY, 16, needleAngle + 180);

  // Ticks
  const { major, minor } = useMemo(() => {
    const major = Array.from({ length: 11 }, (_, i) => {
      const f   = i / 10;
      const deg = START + f * SWEEP;
      const [ox, oy] = ptc(CX, CY, 80, deg);
      const [ix, iy] = ptc(CX, CY, 67, deg);
      const [lx, ly] = ptc(CX, CY, 57, deg);
      const lv = min + f * (max - min);
      return { ox, oy, ix, iy, lx, ly, lv, showLabel: i % 2 === 0 };
    });
    const minor = [];
    for (let i = 0; i < 10; i++) {
      for (let j = 1; j <= 4; j++) {
        const f   = (i + j / 5) / 10;
        const deg = START + f * SWEEP;
        const [ox, oy] = ptc(CX, CY, 80, deg);
        const [ix, iy] = ptc(CX, CY, 74, deg);
        minor.push({ ox, oy, ix, iy });
      }
    }
    return { major, minor };
  }, [min, max]);

  const labelFmt = (v) => {
    if (Math.abs(v) >= 1000) return (v / 1000).toFixed(1) + 'k';
    if (max - min <= 5)      return v.toFixed(1);
    return Math.round(v).toString();
  };

  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '14px 10px 10px' }}>
      {/* Title */}
      <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>
        {label}
      </div>

      <svg width="200" height="190" viewBox="0 0 200 190" style={{ overflow: 'visible' }}>
        <defs>
          {/* Hub gradient */}
          <radialGradient id={`${id}-hub`} cx="40%" cy="35%" r="60%">
            <stop offset="0%"   stopColor="#243f68" />
            <stop offset="100%" stopColor="#060d1c" />
          </radialGradient>

          {/* Glow filters */}
          <filter id={`${id}-glow`} x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="3.5" result="b"/>
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
          <filter id={`${id}-nglow`} x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="b"/>
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
          <filter id={`${id}-hubglow`} x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="4" result="b"/>
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>

        {/* ── Outer decorative zone ring ── */}
        {(zones ?? ZONE_DEFAULT).map((z, i) => {
          const s = START + z.s * SWEEP;
          const e = START + z.e * SWEEP;
          return (
            <path key={i} d={arcD(90, s, e)} fill="none"
              stroke={z.color} strokeWidth="3.5" opacity="0.45" strokeLinecap="round"
            />
          );
        })}

        {/* ── Background track ── */}
        <path d={arcD(74, START, START + SWEEP)} fill="none"
          stroke="#0f1f38" strokeWidth="14" strokeLinecap="round"
        />
        <path d={arcD(74, START, START + SWEEP)} fill="none"
          stroke="#1a3558" strokeWidth="12" strokeLinecap="round" opacity="0.6"
        />

        {/* ── Value arc ── */}
        {pct > 0.005 && (
          <path d={arcD(74, START, valueEndDeg)} fill="none"
            stroke={sc.stroke} strokeWidth="12"
            strokeLinecap="round"
            filter={`url(#${id}-glow)`}
            style={{ transition: 'd 0.6s ease' }}
          />
        )}

        {/* ── Minor ticks ── */}
        {minor.map((t, i) => (
          <line key={i} x1={t.ox} y1={t.oy} x2={t.ix} y2={t.iy}
            stroke="#1e3a5f" strokeWidth="1" strokeLinecap="round"
          />
        ))}

        {/* ── Major ticks + labels ── */}
        {major.map((t, i) => {
          const f = i / 10;
          const activeZones = zones ?? ZONE_DEFAULT;
          const zone = activeZones.find(z => f >= z.s && f <= z.e) ||
                        activeZones[activeZones.length - 1];
          const tColor = zone.color;
          return (
            <g key={i}>
              <line x1={t.ox} y1={t.oy} x2={t.ix} y2={t.iy}
                stroke={tColor} strokeWidth="2.5" strokeLinecap="round" opacity="0.8"
              />
              {t.showLabel && (
                <text x={t.lx} y={t.ly} textAnchor="middle" dominantBaseline="middle"
                  fill="#475569" fontSize="7.5" fontFamily="'JetBrains Mono', monospace"
                >
                  {labelFmt(t.lv)}
                </text>
              )}
            </g>
          );
        })}

        {/* ── Needle shadow ── */}
        <polygon
          points={`${tx},${ty} ${b1x},${b1y} ${rlx},${rly} ${b2x},${b2y}`}
          fill="rgba(0,0,0,0.4)"
          transform="translate(2,3)"
        />

        {/* ── Needle ── */}
        <polygon
          points={`${tx},${ty} ${b1x},${b1y} ${rlx},${rly} ${b2x},${b2y}`}
          fill={sc.stroke}
          filter={`url(#${id}-nglow)`}
          style={{ transition: 'all 0.6s cubic-bezier(0.34,1.56,0.64,1)' }}
        />

        {/* ── Needle tip highlight ── */}
        <circle cx={tx} cy={ty} r={2.5} fill="white" opacity="0.9"
          filter={`url(#${id}-nglow)`}
        />

        {/* ── Center hub ── */}
        {/* Outer ring */}
        <circle cx={CX} cy={CY} r={14} fill={`url(#${id}-hub)`}
          stroke="#243f68" strokeWidth="1.5"
        />
        {/* Middle ring */}
        <circle cx={CX} cy={CY} r={9} fill="#0a1628"
          stroke="#1a3558" strokeWidth="1"
        />
        {/* Inner glowing dot */}
        <circle cx={CX} cy={CY} r={5} fill={sc.stroke}
          filter={`url(#${id}-hubglow)`}
        />
        <circle cx={CX} cy={CY} r={3} fill="white" opacity="0.9" />

        {/* ── Value text ── */}
        <text x={CX} y={CY + 30} textAnchor="middle"
          fill="#e2e8f0" fontSize="22" fontWeight="800"
          fontFamily="'JetBrains Mono', monospace"
          style={{ filter: `drop-shadow(0 0 8px ${sc.stroke}90)` }}
        >
          {typeof value === 'number' ? value.toFixed(decimals) : value}
        </text>

        {/* ── Unit ── */}
        <text x={CX} y={CY + 44} textAnchor="middle"
          fill="#64748b" fontSize="10" fontWeight="600"
        >
          {unit}
        </text>

        {/* ── Min / Max ── */}
        <text x={18}  y={175} textAnchor="middle" fill="#334155" fontSize="8">{min}</text>
        <text x={182} y={175} textAnchor="middle" fill="#334155" fontSize="8">{max}</text>

        {/* ── Status ── */}
        <text x={CX} y={178} textAnchor="middle" fill={sc.text}
          fontSize="9" fontWeight="700" letterSpacing="0.05em"
        >
          ● {sc.label.toUpperCase()}
        </text>
      </svg>
    </div>
  );
}
