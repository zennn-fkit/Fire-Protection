import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useEffect, useState } from 'react';

import { SensorProvider, useSensor } from './context/SensorContext';
import { useSocket } from './hooks/useSocket';
import Sidebar   from './components/layout/Sidebar';
import Dashboard from './pages/Dashboard';
import History   from './pages/History';
import Control   from './pages/Control';

// Inner app: connects socket + mock ticker
function InnerApp() {
  useSocket();
  const { state, mockTick } = useSensor();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // If not connected to backend, run mock data every 3s
  useEffect(() => {
    if (!state.connected) {
      const interval = setInterval(mockTick, 3000);
      return () => clearInterval(interval);
    }
  }, [state.connected, mockTick]);

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar isOpen={isSidebarOpen} onToggle={() => setIsSidebarOpen(!isSidebarOpen)} />
      <main className={`main-content ${!isSidebarOpen ? 'collapsed' : ''}`}>
        <Routes>
          <Route path="/"        element={<Dashboard />} />
          <Route path="/history" element={<History   />} />
          <Route path="/control" element={<Control   />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <SensorProvider>
        <InnerApp />
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#0d1f38',
              color: '#e2e8f0',
              border: '1px solid #1a3558',
              borderRadius: '10px',
              fontSize: '13px',
            },
          }}
        />
      </SensorProvider>
    </BrowserRouter>
  );
}
